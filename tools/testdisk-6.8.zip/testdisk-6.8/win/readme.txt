This version should work under
- Windows NT 4
- Windows 2000
- Windows XP
- Windows 2003

If you are using an older version of Windows,
run the DOS version of TestDisk.

TestDisk doesn't need to be installed, you only need to extract
the full windows subdirectory and run testdisk_win.exe
